-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_number` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applicant_id` bigint unsigned NOT NULL,
  `programme_id` bigint unsigned NOT NULL,
  `admission_cycle_id` bigint unsigned NOT NULL,
  `qualification` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_statement` text COLLATE utf8mb4_unicode_ci,
  `status` enum('DRAFT','SUBMITTED','DOCUMENT_VERIFICATION','ELIGIBILITY_SCREENING','DEPARTMENT_REVIEW','DECISION_PENDING','ADMITTED','REJECTED','WAITLISTED','WITHDRAWN') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `current_stage_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'APPLICATION_SUBMISSION',
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `selected_college_preference_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_applications_number` (`application_number`),
  KEY `idx_applications_applicant` (`applicant_id`,`created_at`),
  KEY `idx_applications_stage_status` (`current_stage_code`,`status`),
  KEY `idx_applications_programme_cycle` (`programme_id`,`admission_cycle_id`),
  KEY `fk_applications_cycle` (`admission_cycle_id`),
  KEY `idx_application_selected_college` (`selected_college_preference_id`),
  CONSTRAINT `fk_applications_applicant` FOREIGN KEY (`applicant_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_applications_cycle` FOREIGN KEY (`admission_cycle_id`) REFERENCES `admission_cycles` (`id`),
  CONSTRAINT `fk_applications_programme` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`id`),
  CONSTRAINT `fk_applications_selected_college_preference` FOREIGN KEY (`selected_college_preference_id`) REFERENCES `application_college_preferences` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_applications_stage` FOREIGN KEY (`current_stage_code`) REFERENCES `application_stages` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (1,'APP-D3C8FEBBF13F',3,2,1,'12th','','ADMITTED','FINAL_ADMISSION_DECISION','2026-11-10 01:52:11','2026-11-09 19:51:56','2026-11-12 12:23:17',NULL),(2,'APP-8378376400FD',7,28,1,'12th','','DEPARTMENT_REVIEW','DEPARTMENT_REVIEW','2026-11-12 18:09:21','2026-11-12 12:38:04','2026-11-12 13:00:04',NULL);
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:20
