-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_stage_history`
--

DROP TABLE IF EXISTS `application_stage_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_stage_history` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint unsigned NOT NULL,
  `from_stage_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_stage_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_status` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actor_user_id` bigint unsigned DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_stage_history_application` (`application_id`,`created_at`),
  KEY `fk_stage_history_from_stage` (`from_stage_code`),
  KEY `fk_stage_history_to_stage` (`to_stage_code`),
  KEY `fk_stage_history_actor` (`actor_user_id`),
  CONSTRAINT `fk_stage_history_actor` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_stage_history_application` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_stage_history_from_stage` FOREIGN KEY (`from_stage_code`) REFERENCES `application_stages` (`code`) ON DELETE SET NULL,
  CONSTRAINT `fk_stage_history_to_stage` FOREIGN KEY (`to_stage_code`) REFERENCES `application_stages` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_stage_history`
--

LOCK TABLES `application_stage_history` WRITE;
/*!40000 ALTER TABLE `application_stage_history` DISABLE KEYS */;
INSERT INTO `application_stage_history` VALUES (1,1,NULL,'APPLICATION_SUBMISSION',NULL,'DRAFT',3,'Application draft created','2026-11-09 19:51:56'),(2,1,'APPLICATION_SUBMISSION','DOCUMENT_VERIFICATION','DRAFT','DOCUMENT_VERIFICATION',3,'Applicant submitted the application.','2026-11-09 20:22:11'),(3,1,'DOCUMENT_VERIFICATION','ELIGIBILITY_SCREENING','DOCUMENT_VERIFICATION','ELIGIBILITY_SCREENING',5,'All mandatory programme documents have been verified.','2026-11-09 20:50:40'),(4,1,'ELIGIBILITY_SCREENING','DEPARTMENT_REVIEW','ELIGIBILITY_SCREENING','DEPARTMENT_REVIEW',5,'The applicant passed all configured eligibility checks.','2026-11-12 12:14:52'),(5,1,'DEPARTMENT_REVIEW','FINAL_ADMISSION_DECISION','DEPARTMENT_REVIEW','DECISION_PENDING',6,'Evaluator submitted the department assessment.','2026-11-12 12:16:22'),(6,1,'FINAL_ADMISSION_DECISION','FINAL_ADMISSION_DECISION','DECISION_PENDING','ADMITTED',1,'well done, congraulations .','2026-11-12 12:23:17'),(7,2,NULL,'APPLICATION_SUBMISSION',NULL,'DRAFT',7,'Application draft created','2026-11-12 12:38:04'),(8,2,'APPLICATION_SUBMISSION','DOCUMENT_VERIFICATION','DRAFT','DOCUMENT_VERIFICATION',7,'Applicant submitted the application.','2026-11-12 12:39:21'),(9,2,'DOCUMENT_VERIFICATION','ELIGIBILITY_SCREENING','DOCUMENT_VERIFICATION','ELIGIBILITY_SCREENING',5,'All mandatory programme documents have been verified.','2026-11-12 12:44:22'),(10,2,'ELIGIBILITY_SCREENING','DEPARTMENT_REVIEW','ELIGIBILITY_SCREENING','DEPARTMENT_REVIEW',5,'The applicant passed all configured eligibility checks.','2026-11-12 13:00:04');
/*!40000 ALTER TABLE `application_stage_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:18
