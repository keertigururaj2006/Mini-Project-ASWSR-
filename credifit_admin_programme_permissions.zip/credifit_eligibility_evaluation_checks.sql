-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eligibility_evaluation_checks`
--

DROP TABLE IF EXISTS `eligibility_evaluation_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eligibility_evaluation_checks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `evaluation_id` bigint unsigned NOT NULL,
  `criterion` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` enum('PASS','FAIL','PENDING') COLLATE utf8mb4_unicode_ci NOT NULL,
  `explanation` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `actual_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expected_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_eligibility_checks_eval` (`evaluation_id`),
  CONSTRAINT `fk_eligibility_checks_evaluation` FOREIGN KEY (`evaluation_id`) REFERENCES `eligibility_evaluations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eligibility_evaluation_checks`
--

LOCK TABLES `eligibility_evaluation_checks` WRITE;
/*!40000 ALTER TABLE `eligibility_evaluation_checks` DISABLE KEYS */;
INSERT INTO `eligibility_evaluation_checks` VALUES (1,1,'Minimum academic percentage','PASS','Recorded percentage 77.5% meets the minimum 75%.','77.5','75'),(2,1,'Required document: 10th Standard Marks Card','PASS','10th Standard Marks Card has been verified.','Verified','Verified'),(3,1,'Required document: 12th / PUC Marks Card','PASS','12th / PUC Marks Card has been verified.','Verified','Verified'),(4,1,'Required document: Leaving Certificate','PASS','Leaving Certificate has been verified.','Verified','Verified'),(5,1,'Required document: Degree Certificate','PASS','Degree Certificate has been verified.','Verified','Verified'),(6,2,'Minimum academic percentage','PASS','Recorded percentage 81.58% meets the minimum 80%.','81.58','80'),(7,2,'Required document: 10th Standard Marks Card','PASS','10th Standard Marks Card has been verified.','Verified','Verified'),(8,2,'Required document: 12th / PUC Marks Card','PASS','12th / PUC Marks Card has been verified.','Verified','Verified'),(9,2,'Required document: Leaving Certificate','PASS','Leaving Certificate has been verified.','Verified','Verified'),(10,2,'Required document: Degree Certificate','PENDING','Degree Certificate is not yet verified.','Not verified','Verified'),(11,3,'Minimum academic percentage','PASS','Recorded percentage 81.58% meets the minimum 80%.','81.58','80'),(12,3,'Required document: 10th Standard Marks Card','PASS','10th Standard Marks Card has been verified.','Verified','Verified'),(13,3,'Required document: 12th / PUC Marks Card','PASS','12th / PUC Marks Card has been verified.','Verified','Verified'),(14,3,'Required document: Leaving Certificate','PASS','Leaving Certificate has been verified.','Verified','Verified'),(15,3,'Required document: Degree Certificate','PENDING','Degree Certificate is not yet verified.','Not verified','Verified'),(16,4,'Minimum academic percentage','PASS','Recorded percentage 81.58% meets the minimum 80%.','81.58','80'),(17,4,'Required document: 10th Standard Marks Card','PASS','10th Standard Marks Card has been verified.','Verified','Verified'),(18,4,'Required document: 12th / PUC Marks Card','PASS','12th / PUC Marks Card has been verified.','Verified','Verified'),(19,4,'Required document: Leaving Certificate','PASS','Leaving Certificate has been verified.','Verified','Verified');
/*!40000 ALTER TABLE `eligibility_evaluation_checks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:19
