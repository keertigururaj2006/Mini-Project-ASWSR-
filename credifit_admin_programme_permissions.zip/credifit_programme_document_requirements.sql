-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `programme_document_requirements`
--

DROP TABLE IF EXISTS `programme_document_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programme_document_requirements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `programme_id` bigint unsigned NOT NULL,
  `document_type_id` bigint unsigned NOT NULL,
  `qualification` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '*',
  `is_mandatory` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` smallint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_programme_document_requirement` (`programme_id`,`document_type_id`,`qualification`),
  KEY `idx_programme_requirements_active` (`programme_id`,`is_active`,`is_mandatory`),
  KEY `fk_pdr_document_type` (`document_type_id`),
  CONSTRAINT `fk_pdr_document_type` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`),
  CONSTRAINT `fk_pdr_programme` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=274 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programme_document_requirements`
--

LOCK TABLES `programme_document_requirements` WRITE;
/*!40000 ALTER TABLE `programme_document_requirements` DISABLE KEYS */;
INSERT INTO `programme_document_requirements` VALUES (1,3,3,'*',1,1,3),(2,3,2,'*',1,1,2),(3,3,1,'*',1,1,1),(4,50,3,'*',1,1,3),(5,50,2,'*',1,1,2),(6,50,1,'*',1,1,1),(7,32,3,'*',1,1,3),(8,32,2,'*',1,1,2),(9,32,1,'*',1,1,1),(10,40,3,'*',1,1,3),(11,40,2,'*',1,1,2),(12,40,1,'*',1,1,1),(13,35,3,'*',1,1,3),(14,35,2,'*',1,1,2),(15,35,1,'*',1,1,1),(16,41,3,'*',1,1,3),(17,41,2,'*',1,1,2),(18,41,1,'*',1,1,1),(19,29,3,'*',1,1,3),(20,29,2,'*',1,1,2),(21,29,1,'*',1,1,1),(22,45,3,'*',1,1,3),(23,45,2,'*',1,1,2),(24,45,1,'*',1,1,1),(25,13,3,'*',1,1,3),(26,13,2,'*',1,1,2),(27,13,1,'*',1,1,1),(28,17,3,'*',1,1,3),(29,17,2,'*',1,1,2),(30,17,1,'*',1,1,1),(31,25,3,'*',1,1,3),(32,25,2,'*',1,1,2),(33,25,1,'*',1,1,1),(34,23,3,'*',1,1,3),(35,23,2,'*',1,1,2),(36,23,1,'*',1,1,1),(37,20,3,'*',1,1,3),(38,20,2,'*',1,1,2),(39,20,1,'*',1,1,1),(40,18,3,'*',1,1,3),(41,18,2,'*',1,1,2),(42,18,1,'*',1,1,1),(43,24,3,'*',1,1,3),(44,24,2,'*',1,1,2),(45,24,1,'*',1,1,1),(46,26,3,'*',1,1,3),(47,26,2,'*',1,1,2),(48,26,1,'*',1,1,1),(49,12,3,'*',1,1,3),(50,12,2,'*',1,1,2),(51,12,1,'*',1,1,1),(52,22,3,'*',1,1,3),(53,22,2,'*',1,1,2),(54,22,1,'*',1,1,1),(55,34,3,'*',1,1,3),(56,34,2,'*',1,1,2),(57,34,1,'*',1,1,1),(58,33,3,'*',1,1,3),(59,33,2,'*',1,1,2),(60,33,1,'*',1,1,1),(61,38,3,'*',1,1,3),(62,38,2,'*',1,1,2),(63,38,1,'*',1,1,1),(64,28,3,'*',1,1,3),(65,28,2,'*',1,1,2),(66,28,1,'*',1,1,1),(67,2,3,'*',1,1,3),(68,2,2,'*',1,1,2),(69,2,1,'*',1,1,1),(70,11,3,'*',1,1,3),(71,11,2,'*',1,1,2),(72,11,1,'*',1,1,1),(73,44,3,'*',1,1,3),(74,44,2,'*',1,1,2),(75,44,1,'*',1,1,1),(76,21,3,'*',1,1,3),(77,21,2,'*',1,1,2),(78,21,1,'*',1,1,1),(79,47,3,'*',1,1,3),(80,47,2,'*',1,1,2),(81,47,1,'*',1,1,1),(82,14,3,'*',1,1,3),(83,14,2,'*',1,1,2),(84,14,1,'*',1,1,1),(85,19,3,'*',1,1,3),(86,19,2,'*',1,1,2),(87,19,1,'*',1,1,1),(88,6,3,'*',1,1,3),(89,6,2,'*',1,1,2),(90,6,1,'*',1,1,1),(91,1,3,'*',1,1,3),(92,1,2,'*',1,1,2),(93,1,1,'*',1,1,1),(94,51,3,'*',1,1,3),(95,51,2,'*',1,1,2),(96,51,1,'*',1,1,1),(97,9,3,'*',1,1,3),(98,9,2,'*',1,1,2),(99,9,1,'*',1,1,1),(100,7,3,'*',1,1,3),(101,7,2,'*',1,1,2),(102,7,1,'*',1,1,1),(103,27,3,'*',1,1,3),(104,27,2,'*',1,1,2),(105,27,1,'*',1,1,1),(106,43,3,'*',1,1,3),(107,43,2,'*',1,1,2),(108,43,1,'*',1,1,1),(109,42,3,'*',1,1,3),(110,42,2,'*',1,1,2),(111,42,1,'*',1,1,1),(112,4,3,'*',1,1,3),(113,4,2,'*',1,1,2),(114,4,1,'*',1,1,1),(115,36,3,'*',1,1,3),(116,36,2,'*',1,1,2),(117,36,1,'*',1,1,1),(118,37,3,'*',1,1,3),(119,37,2,'*',1,1,2),(120,37,1,'*',1,1,1),(121,39,3,'*',1,1,3),(122,39,2,'*',1,1,2),(123,39,1,'*',1,1,1),(124,31,3,'*',1,1,3),(125,31,2,'*',1,1,2),(126,31,1,'*',1,1,1),(127,46,3,'*',1,1,3),(128,46,2,'*',1,1,2),(129,46,1,'*',1,1,1),(130,30,3,'*',1,1,3),(131,30,2,'*',1,1,2),(132,30,1,'*',1,1,1),(133,10,3,'*',1,1,3),(134,10,2,'*',1,1,2),(135,10,1,'*',1,1,1),(136,8,3,'*',1,1,3),(137,8,2,'*',1,1,2),(138,8,1,'*',1,1,1),(139,5,3,'*',1,1,3),(140,5,2,'*',1,1,2),(141,5,1,'*',1,1,1),(142,15,3,'*',1,1,3),(143,15,2,'*',1,1,2),(144,15,1,'*',1,1,1),(145,16,3,'*',1,1,3),(146,16,2,'*',1,1,2),(147,16,1,'*',1,1,1),(148,49,3,'*',1,1,3),(149,49,2,'*',1,1,2),(150,49,1,'*',1,1,1),(151,48,3,'*',1,1,3),(152,48,2,'*',1,1,2),(153,48,1,'*',1,1,1),(256,8,4,'*',1,1,4),(257,16,4,'*',1,1,4),(258,30,4,'*',1,1,4),(259,31,4,'*',1,1,4),(260,39,4,'*',1,1,4),(261,46,4,'*',1,1,4),(263,2,1,'12th',1,1,1),(264,2,2,'12th',1,1,2),(265,2,3,'12th',1,1,3),(266,2,4,'12th',1,1,4),(267,28,1,'12th',1,1,1),(268,28,2,'12th',1,1,2),(269,28,3,'12th',1,1,3),(270,28,4,'12th',1,0,4);
/*!40000 ALTER TABLE `programme_document_requirements` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:17
