-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `document_reviews`
--

DROP TABLE IF EXISTS `document_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_document_id` bigint unsigned NOT NULL,
  `reviewer_user_id` bigint unsigned NOT NULL,
  `decision` enum('VERIFIED','CLARIFICATION_REQUESTED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(1500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(1500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_document_reviews_doc` (`application_document_id`,`reviewed_at`),
  KEY `idx_document_reviews_reviewer` (`reviewer_user_id`,`reviewed_at`),
  CONSTRAINT `fk_document_reviews_document` FOREIGN KEY (`application_document_id`) REFERENCES `application_documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_document_reviews_reviewer` FOREIGN KEY (`reviewer_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_reviews`
--

LOCK TABLES `document_reviews` WRITE;
/*!40000 ALTER TABLE `document_reviews` DISABLE KEYS */;
INSERT INTO `document_reviews` VALUES (1,1,5,'VERIFIED',NULL,NULL,'2026-11-09 20:50:22'),(2,2,5,'VERIFIED',NULL,NULL,'2026-11-09 20:50:35'),(3,4,5,'VERIFIED',NULL,NULL,'2026-11-09 20:50:38'),(4,3,5,'VERIFIED',NULL,NULL,'2026-11-09 20:50:40'),(5,5,5,'VERIFIED',NULL,NULL,'2026-11-12 12:40:58'),(6,6,5,'REJECTED','The document is blur',NULL,'2026-11-12 12:41:22'),(7,7,5,'VERIFIED',NULL,NULL,'2026-11-12 12:41:27'),(8,8,5,'VERIFIED',NULL,NULL,'2026-11-12 12:44:22');
/*!40000 ALTER TABLE `document_reviews` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:17
