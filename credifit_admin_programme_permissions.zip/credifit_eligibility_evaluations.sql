-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eligibility_evaluations`
--

DROP TABLE IF EXISTS `eligibility_evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eligibility_evaluations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint unsigned NOT NULL,
  `rule_id` bigint unsigned NOT NULL,
  `evaluated_by_user_id` bigint unsigned NOT NULL,
  `status` enum('ELIGIBLE','NOT_ELIGIBLE','INCOMPLETE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` decimal(5,2) DEFAULT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `evaluated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_eligibility_eval_application` (`application_id`,`evaluated_at`),
  KEY `fk_eligibility_eval_rule` (`rule_id`),
  KEY `fk_eligibility_eval_actor` (`evaluated_by_user_id`),
  CONSTRAINT `fk_eligibility_eval_actor` FOREIGN KEY (`evaluated_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_eligibility_eval_application` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eligibility_eval_rule` FOREIGN KEY (`rule_id`) REFERENCES `eligibility_rules` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eligibility_evaluations`
--

LOCK TABLES `eligibility_evaluations` WRITE;
/*!40000 ALTER TABLE `eligibility_evaluations` DISABLE KEYS */;
INSERT INTO `eligibility_evaluations` VALUES (1,1,1,5,'ELIGIBLE',77.50,'The applicant meets the configured eligibility criteria.','2026-11-12 12:14:52'),(2,2,2,5,'INCOMPLETE',81.58,'Eligibility screening is incomplete because required information or document verification is pending.','2026-11-12 12:48:30'),(3,2,2,5,'INCOMPLETE',81.58,'Eligibility screening is incomplete because required information or document verification is pending.','2026-11-12 12:49:20'),(4,2,2,5,'ELIGIBLE',81.58,'The applicant meets the configured eligibility criteria.','2026-11-12 13:00:04');
/*!40000 ALTER TABLE `eligibility_evaluations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:20
