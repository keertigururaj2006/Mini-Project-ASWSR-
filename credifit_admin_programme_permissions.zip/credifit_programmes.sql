-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `programmes`
--

DROP TABLE IF EXISTS `programmes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programmes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `department` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intake_capacity` int unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_programmes_code` (`code`),
  UNIQUE KEY `uq_programmes_name` (`name`),
  KEY `idx_programmes_active_category` (`is_active`,`category`),
  KEY `idx_programmes_short_code` (`short_code`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programmes`
--

LOCK TABLES `programmes` WRITE;
/*!40000 ALTER TABLE `programmes` DISABLE KEYS */;
INSERT INTO `programmes` VALUES (1,'CSE','Computer Science Engineering','CSE','Engineering & Technology','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:04'),(2,'BCA','Bachelor of Computer Applications','BCA','Engineering & Technology','Undergraduate','3 Years','','',NULL,1,'2026-11-09 10:11:35','2026-11-10 13:51:09'),(3,'AI/ML','Artificial Intelligence & Machine Learning','AI/ML','Engineering & Technology','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:03'),(4,'ISE','Information Science','ISE','Engineering & Technology','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:05'),(5,'ME','Mechanical Engineering','ME','Engineering & Technology','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:05'),(6,'CE','Civil Engineering','CE','Engineering & Technology','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:04'),(7,'ECE','Electronics & Communication Engineering','ECE','Engineering & Technology','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:04'),(8,'MCA','Master of Computer Applications','MCA','Engineering & Technology','Postgraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:05'),(9,'DIP-ENG','Polytechnic Diploma in Engineering','DIP-ENG','Engineering & Technology','Diploma','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:06'),(10,'MBBS','Bachelor of Medicine and Bachelor of Surgery','MBBS','Medical & Healthcare','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:07'),(11,'BDS','Bachelor of Dental Surgery','BDS','Medical & Healthcare','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:07'),(12,'B.Sc Nursing','Bachelor of Science in Nursing','B.Sc Nursing','Medical & Healthcare','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:08'),(13,'B.Pharm','Bachelor of Pharmacy','B.Pharm','Medical & Healthcare','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:07'),(14,'BPT','Bachelor of Physiotherapy','BPT','Medical & Healthcare','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:08'),(15,'MLT','Medical Laboratory Technology','MLT','Medical & Healthcare','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:08'),(16,'MPH','Master of Public Health','MPH','Medical & Healthcare','Postgraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:08'),(17,'B.Sc Agri','Bachelor of Science in Agriculture','B.Sc Agri','Agriculture & Veterinary','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:56'),(18,'B.Sc Hort','Horticulture','B.Sc Hort','Agriculture & Veterinary','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:58'),(19,'BVSc','Veterinary Science','BVSc','Agriculture & Veterinary','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:58'),(20,'B.Sc Forestry','Forestry','B.Sc Forestry','Agriculture & Veterinary','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:57'),(21,'BFSc','Fisheries Science','BFSc','Agriculture & Veterinary','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:57'),(22,'B.Sc Physics','Physics','B.Sc Physics','Science & Research','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:11'),(23,'B.Sc Chemistry','Chemistry','B.Sc Chemistry','Science & Research','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:09'),(24,'B.Sc Maths','Mathematics','B.Sc Maths','Science & Research','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:10'),(25,'B.Sc Biotech','Biotechnology','B.Sc Biotech','Science & Research','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:09'),(26,'B.Sc Micro','Microbiology','B.Sc Micro','Science & Research','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:10'),(27,'Env. Sci','Environmental Science','Env. Sci','Science & Research','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:09'),(28,'BBA','Bachelor of Business Administration','BBA','Business & Commerce','Undergraduate','To be announced','','',NULL,1,'2026-11-09 10:11:35','2026-11-10 14:07:39'),(29,'B.Com','Bachelor of Commerce','B.Com','Business & Commerce','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:01'),(30,'MBA','Master of Business Administration','MBA','Business & Commerce','Postgraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:01'),(31,'M.Com','Master of Commerce','M.Com','Business & Commerce','Postgraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:02'),(32,'B.A. Econ','Economics','B.A. Econ','Business & Commerce','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:01'),(33,'BA','Bachelor of Arts','BA','Arts & Social Sciences','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:59'),(34,'B.Sc Psych','Psychology','B.Sc Psych','Arts & Social Sciences','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:59'),(35,'B.A. Soc','Sociology','B.A. Soc','Arts & Social Sciences','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:59'),(36,'JMC','Journalism & Mass Communication','JMC','Arts & Social Sciences','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:59'),(37,'LLB','Bachelor of Laws','LLB','Law & Public Policy','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:06'),(38,'BA LLB','Integrated BA LLB','BA LLB','Law & Public Policy','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:06'),(39,'LLM','Master of Laws','LLM','Law & Public Policy','Postgraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:06'),(40,'B.A. Pol Sci','Political Science','B.A. Pol Sci','Law & Public Policy','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:07'),(41,'B.Arch','Bachelor of Architecture','B.Arch','Architecture & Design','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:58'),(42,'Interior','Interior Design','Interior','Architecture & Design','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:59'),(43,'Fashion','Fashion Design','Fashion','Architecture & Design','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:58'),(44,'BFA','Fine Arts','BFA','Architecture & Design','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:29:58'),(45,'B.Ed','Bachelor of Education','B.Ed','Education & Hospitality','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:02'),(46,'M.Ed','Master of Education','M.Ed','Education & Hospitality','Postgraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:03'),(47,'BHM','Hotel Management','BHM','Education & Hospitality','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:02'),(48,'Tourism','Tourism Management','Tourism','Education & Hospitality','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:03'),(49,'Sports Sci','Physical Education & Sports Science','Sports Sci','Sports & Other Fields','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:12'),(50,'Aviation','Aviation Management','Aviation','Sports & Other Fields','Undergraduate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:11'),(51,'Data Cert','Certificate in Data Analytics','Data Cert','Sports & Other Fields','Certificate','To be announced','','',NULL,0,'2026-11-09 10:11:35','2026-11-09 18:30:11');
/*!40000 ALTER TABLE `programmes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:19
