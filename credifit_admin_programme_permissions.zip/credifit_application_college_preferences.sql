-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_college_preferences`
--

DROP TABLE IF EXISTS `application_college_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_college_preferences` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint unsigned NOT NULL,
  `college_programme_id` bigint unsigned NOT NULL,
  `preference_order` smallint unsigned NOT NULL,
  `college_percentage_pass` tinyint(1) DEFAULT NULL,
  `programme_percentage_pass` tinyint(1) DEFAULT NULL,
  `document_check_pass` tinyint(1) DEFAULT NULL,
  `overall_eligibility_status` enum('PENDING','ELIGIBLE','NOT_ELIGIBLE','INCOMPLETE') NOT NULL DEFAULT 'PENDING',
  `eligibility_checks` json DEFAULT NULL,
  `evaluated_at` datetime DEFAULT NULL,
  `review_status` enum('NOT_STARTED','IN_REVIEW','DECISION_PENDING','COMPLETED') NOT NULL DEFAULT 'NOT_STARTED',
  `final_decision` enum('PENDING','ADMITTED','REJECTED','WAITLISTED') NOT NULL DEFAULT 'PENDING',
  `final_decision_remarks` text,
  `final_decided_at` datetime DEFAULT NULL,
  `is_current` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_application_preference_order` (`application_id`,`preference_order`),
  UNIQUE KEY `uq_application_college_programme` (`application_id`,`college_programme_id`),
  KEY `idx_preference_eligibility` (`application_id`,`overall_eligibility_status`),
  KEY `fk_application_college_preference_offering` (`college_programme_id`),
  CONSTRAINT `fk_application_college_preference_application` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`),
  CONSTRAINT `fk_application_college_preference_offering` FOREIGN KEY (`college_programme_id`) REFERENCES `college_programmes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_college_preferences`
--

LOCK TABLES `application_college_preferences` WRITE;
/*!40000 ALTER TABLE `application_college_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_college_preferences` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:18
