-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_documents`
--

DROP TABLE IF EXISTS `application_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint unsigned NOT NULL,
  `document_type_id` bigint unsigned NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stored_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storage_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size_bytes` int unsigned NOT NULL,
  `status` enum('PENDING','VERIFIED','CLARIFICATION_REQUESTED','REJECTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `version_number` smallint unsigned NOT NULL DEFAULT '1',
  `is_latest` tinyint(1) NOT NULL DEFAULT '1',
  `uploaded_by_user_id` bigint unsigned NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_documents_application_latest` (`application_id`,`is_latest`),
  KEY `idx_documents_status` (`status`,`uploaded_at`),
  KEY `idx_documents_type` (`document_type_id`),
  KEY `fk_documents_uploader` (`uploaded_by_user_id`),
  CONSTRAINT `fk_documents_application` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_documents_type` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`),
  CONSTRAINT `fk_documents_uploader` FOREIGN KEY (`uploaded_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_documents`
--

LOCK TABLES `application_documents` WRITE;
/*!40000 ALTER TABLE `application_documents` DISABLE KEYS */;
INSERT INTO `application_documents` VALUES (1,1,1,'ilovepdf_merged (1)_organized.pdf','5f63a1db-4304-486c-8882-40cbe175801a.pdf','D:\\CrediFit\\backend\\storage\\uploads\\5f63a1db-4304-486c-8882-40cbe175801a.pdf','application/pdf',2004124,'VERIFIED',1,1,3,'2026-11-09 19:51:56'),(2,1,2,'ilovepdf_merged (1)_organized - Copy.pdf','d94cbf57-8668-4afb-b385-e478f34e0c55.pdf','D:\\CrediFit\\backend\\storage\\uploads\\d94cbf57-8668-4afb-b385-e478f34e0c55.pdf','application/pdf',1983160,'VERIFIED',1,1,3,'2026-11-09 20:22:00'),(3,1,3,'30723e20-6adb-4919-b816-29fece9895b8.pdf','7f3f2607-4272-4584-b66f-24018b400f2f.pdf','D:\\CrediFit\\backend\\storage\\uploads\\7f3f2607-4272-4584-b66f-24018b400f2f.pdf','application/pdf',1435292,'VERIFIED',1,1,3,'2026-11-09 20:22:04'),(4,1,4,'ilovepdf_merged (1)_organized - Copy.pdf','6e0297b6-d7cf-4f31-9980-c2cab099c93f.pdf','D:\\CrediFit\\backend\\storage\\uploads\\6e0297b6-d7cf-4f31-9980-c2cab099c93f.pdf','application/pdf',1983160,'VERIFIED',1,1,3,'2026-11-09 20:22:07'),(5,2,1,'ilovepdf_merged (1)_organized - Copy (1).pdf','e4b08695-85c3-4d0d-9420-4ec58ff7511a.pdf','D:\\CrediFit\\backend\\storage\\uploads\\e4b08695-85c3-4d0d-9420-4ec58ff7511a.pdf','application/pdf',1983160,'VERIFIED',1,1,7,'2026-11-12 12:38:21'),(6,2,2,'ilovepdf_merged (1)_organized - Copy.pdf','e6050c73-55e7-4365-ab4b-bf6eab16bead.pdf','D:\\CrediFit\\backend\\storage\\uploads\\e6050c73-55e7-4365-ab4b-bf6eab16bead.pdf','application/pdf',1983160,'REJECTED',1,0,7,'2026-11-12 12:38:24'),(7,2,3,'ilovepdf_merged (1)_organized - Copy.pdf','03600bc2-beae-4a3c-a54b-6f0aac466844.pdf','D:\\CrediFit\\backend\\storage\\uploads\\03600bc2-beae-4a3c-a54b-6f0aac466844.pdf','application/pdf',1983160,'VERIFIED',1,1,7,'2026-11-12 12:38:27'),(8,2,2,'ilovepdf_merged (1)_organized - Copy.pdf','c36c3248-fc1e-4361-9802-a07c7cac2616.pdf','D:\\CrediFit\\backend\\storage\\uploads\\c36c3248-fc1e-4361-9802-a07c7cac2616.pdf','application/pdf',1983160,'VERIFIED',2,1,7,'2026-11-12 12:43:57');
/*!40000 ALTER TABLE `application_documents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:18
