-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `evaluator_assignments`
--

DROP TABLE IF EXISTS `evaluator_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluator_assignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint unsigned NOT NULL,
  `evaluator_user_id` bigint unsigned NOT NULL,
  `assigned_by_user_id` bigint unsigned NOT NULL,
  `due_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `college_preference_id` bigint unsigned DEFAULT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `college_preference_scope_id` bigint unsigned GENERATED ALWAYS AS (coalesce(`college_preference_id`,0)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_evaluator_assignment_preference` (`application_id`,`college_preference_scope_id`,`evaluator_user_id`),
  KEY `idx_evaluator_assignments_evaluator` (`evaluator_user_id`,`is_active`,`due_date`),
  KEY `fk_assignment_admin` (`assigned_by_user_id`),
  KEY `idx_evaluator_college_preference` (`college_preference_id`),
  CONSTRAINT `fk_assignment_admin` FOREIGN KEY (`assigned_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_assignment_application` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_assignment_college_preference` FOREIGN KEY (`college_preference_id`) REFERENCES `application_college_preferences` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_assignment_evaluator` FOREIGN KEY (`evaluator_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluator_assignments`
--

LOCK TABLES `evaluator_assignments` WRITE;
/*!40000 ALTER TABLE `evaluator_assignments` DISABLE KEYS */;
INSERT INTO `evaluator_assignments` (`id`, `application_id`, `evaluator_user_id`, `assigned_by_user_id`, `due_date`, `is_active`, `college_preference_id`, `assigned_at`, `updated_at`) VALUES (1,1,6,1,NULL,1,NULL,'2026-11-12 12:15:21','2026-11-12 12:15:21'),(2,2,6,1,NULL,1,NULL,'2026-11-12 13:00:32','2026-11-12 13:00:32');
/*!40000 ALTER TABLE `evaluator_assignments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:18
