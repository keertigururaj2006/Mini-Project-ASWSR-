-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: credifit
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `public_id` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` tinyint unsigned NOT NULL,
  `full_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_country_code` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT '+91',
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_photo_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` enum('ACTIVE','INACTIVE','SUSPENDED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `email_verified_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_public_id` (`public_id`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_role_status` (`role_id`,`account_status`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'CF-E0ADCA357CC0',4,'Aditya','adityaapatil51@gmail.com','$2b$12$8/aHzpAA3LpLX7Yi00f/Tu1rYIKouKx6QbDWXVlqTmMP.cXZuGxHW','+91',NULL,NULL,'ACTIVE',NULL,'2026-11-21 08:38:00','2026-11-09 10:14:06','2026-11-21 03:08:00'),(2,'CF-CB32ECD074C1',3,'Bhagya','bhagyasm10@gmail.com','$2b$12$QrbccCeMG8BNEn5aOLXb2eae07RPSlEMcjqSW7jszEu8HyS6lkUzC','+91',NULL,NULL,'INACTIVE',NULL,'2026-11-09 20:31:57','2026-11-09 15:01:13','2026-11-09 20:56:05'),(3,'CF-52008ED268B8',1,'hijda','hijdapromax@gmail.com','$2b$12$/cQdSytc9aqSLqHqzHZ8zOuf5o8aGuE7M7as0LvZDCOqqQxJ3ULny','+91','1234567890',NULL,'ACTIVE',NULL,'2026-11-12 20:00:03','2026-11-09 17:00:38','2026-11-12 14:30:03'),(5,'CF-A779FA5B4265',2,'Keerthi','keerthikle@gmail.com','$2b$12$pKfwqptJQYda0bImHVHp5Ouv6ROPusmMYoKT3gfyxIcYTL3INti2G','+91',NULL,NULL,'ACTIVE',NULL,'2026-11-12 18:52:01','2026-11-09 20:48:20','2026-11-12 13:22:01'),(6,'CF-B17622A02D64',3,'Bhagya','bhagyasmkle@gmail.com','$2b$12$2mmPKEc50DTA0IbwvF2mnelXu4jVlmbbZHpEF7JuB2JWWJvF3yICa','+91',NULL,NULL,'ACTIVE',NULL,'2026-11-12 18:52:38','2026-11-09 20:56:32','2026-11-12 13:22:38'),(7,'CF-43FA012CB89B',1,'Good Night','goodnight@gmail.com','$2b$12$XLG7PuaAzgGhJczfCj/a2.mTgHQ0F0MM/J5jonMbjASQMQLSZFpji','+91','1234567890',NULL,'ACTIVE',NULL,'2026-11-13 20:34:51','2026-11-12 12:37:55','2026-11-13 15:04:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-21  9:01:17
